#!/bin/bash

if [ "$1" = "-help" ]; then
	echo "Uso: $0 -origen <directorio> -destino <directorio>"
	echo "Ejemplo: $0 -origen /var/log -destino /backup_dir"
	exit 0
fi

if [ "$1" = "-origen" ]; then
	ORIGEN="$2"
fi

if [ "$3" = "-destino" ]; then
	DESTINO="$4"
fi

if [ -z "$ORIGEN" ] || [ -z "$DESTINO" ]; then
	echo "Error: debe especificar -origen y -destino"
	echo "Use -help para mas informacion"
	exit 1
fi

if [ ! -d "$ORIGEN" ];then
	echo "Error: el origen $ORIGEN no esta disponible"
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: el destino $DESTINO no esta disponible"
	exit 1
fi

FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"
echo "Backup creado: $DESTINO/$ARCHIVO"
